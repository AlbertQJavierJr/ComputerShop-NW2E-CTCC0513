package finals;

import java.awt.Image;
import java.sql.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



public class Create extends javax.swing.JFrame {

    public Create() {
        initComponents();
        SIClogo();
        Connect();
        LoadUserId();
        Fetch();

    }

    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public void Connect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/creating", "root", "");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Create.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Create.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void SIClogo() {
        ImageIcon SIC = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\BG.jpg");
        Image img = SIC.getImage();
        Image imgScale = img.getScaledInstance(BG.getWidth(), BG.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledLogo = new ImageIcon(imgScale);
        BG.setIcon(scaledLogo);
    }

    public void LoadUserId() {

        try {
            pst = con.prepareStatement("SELECT Name FROM name");
            rs = pst.executeQuery();
            CB1.removeAllItems();
            while (rs.next()) {
                CB1.addItem(rs.getString(1));

            }
        } catch (SQLException ex) {
            Logger.getLogger(Create.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void Fetch() {
        try {
            int x;
            pst = con.prepareStatement("SELECT * FROM name  ");
            rs = pst.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            x = rss.getColumnCount();

            DefaultTableModel rf = (DefaultTableModel) jTable1.getModel();
            rf.setRowCount(0);
            while (rs.next()) {
                Vector V = new Vector();
                for (int y = 1; y <= x; y++) {
                    V.add(rs.getString("Name"));
                    V.add(rs.getString("Age"));
                    V.add(rs.getString("Password"));
                    V.add(rs.getString("Name"));
                }
                rf.addRow(V);

            }

        } catch (SQLException ex) {
            Logger.getLogger(Create.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        TF1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        TF2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        S1 = new javax.swing.JButton();
        C1 = new javax.swing.JButton();
        D1 = new javax.swing.JButton();
        U1 = new javax.swing.JButton();
        C2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        CB1 = new javax.swing.JComboBox<>();
        TF3 = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        BG = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Creating Account");
        setResizable(false);

        jPanel2.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Name:");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(42, 114, 50, 22);

        TF1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jPanel2.add(TF1);
        TF1.setBounds(146, 111, 200, 28);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Age:");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(42, 188, 35, 22);

        TF2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        TF2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TF2ActionPerformed(evt);
            }
        });
        jPanel2.add(TF2);
        TF2.setBounds(146, 185, 200, 28);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Password:");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(42, 259, 78, 22);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("User Id:");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(549, 114, 62, 22);

        S1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        S1.setText("Search");
        S1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                S1ActionPerformed(evt);
            }
        });
        jPanel2.add(S1);
        S1.setBounds(708, 152, 85, 31);

        C1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        C1.setText("Create");
        C1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                C1ActionPerformed(evt);
            }
        });
        jPanel2.add(C1);
        C1.setBounds(126, 333, 83, 31);

        D1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        D1.setText("Delete");
        D1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                D1ActionPerformed(evt);
            }
        });
        jPanel2.add(D1);
        D1.setBounds(319, 333, 81, 31);

        U1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        U1.setText("Update");
        U1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                U1ActionPerformed(evt);
            }
        });
        jPanel2.add(U1);
        U1.setBounds(500, 333, 89, 31);

        C2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        C2.setText("Clear");
        C2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                C2ActionPerformed(evt);
            }
        });
        jPanel2.add(C2);
        C2.setBounds(699, 333, 75, 31);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Name", "Age", "Password", "User Id"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
        }

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(40, 380, 808, 320);

        CB1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jPanel2.add(CB1);
        CB1.setBounds(650, 111, 200, 28);

        TF3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jPanel2.add(TF3);
        TF3.setBounds(146, 256, 200, 28);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Creating Account");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(10, 20, 860, 28);

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton1.setText("Waiting");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(700, 190, 100, 25);
        jPanel2.add(BG);
        BG.setBounds(0, 0, 900, 730);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 898, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 734, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void C1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_C1ActionPerformed

        try {
            String name = TF1.getText();
            String age = TF2.getText();
            String password = TF3.getText();

            pst = con.prepareStatement("INSERT INTO name (Name,Age,Password)VALUES(?,?,?)");
            pst.setString(1, name);
            pst.setString(2, age);
            pst.setString(3, password);

            int k = pst.executeUpdate();

            if (k == 1) {
                JOptionPane.showMessageDialog(this, "Account added successfully!");
                TF1.setText("");
                TF2.setText("");
                TF3.setText("");
                Fetch();
                LoadUserId();

            } else {
                JOptionPane.showMessageDialog(this, "Account Failed to save!!", "Alert", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            Logger.getLogger(Create.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_C1ActionPerformed

    private void U1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_U1ActionPerformed

        try {
            String name = TF1.getText();
            String age = TF2.getText();
            String password = TF3.getText();
            String userid = CB1.getSelectedItem().toString();
            pst = con.prepareStatement("UPDATE name SET Name=?,Age=?,Password=? WHERE name=?");

            pst.setString(1, name);
            pst.setString(2, age);
            pst.setString(3, password);
            pst.setString(4, userid);

            int k = pst.executeUpdate();

            if (k == 1) {
                JOptionPane.showMessageDialog(this, "Account has been successfully update!!");
                TF1.setText("");
                TF2.setText("");
                TF3.setText("");
                TF1.requestFocus();
                Fetch();
                LoadUserId();
            }

        } catch (SQLException ex) {
            Logger.getLogger(Create.class.getName()).log(Level.SEVERE, null, ex);

        }
    }//GEN-LAST:event_U1ActionPerformed

    private void D1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_D1ActionPerformed

        try {
            String Combo = CB1.getSelectedItem().toString();
            pst = con.prepareStatement("DELETE FROM name WHERE name=?");
            pst.setString(1, Combo);

            int k = pst.executeUpdate();
            if (k == 1) {
                JOptionPane.showMessageDialog(this, "Account has been successfully Deleted!!");
                TF1.setText("");
                TF2.setText("");
                TF3.setText("");
                TF1.requestFocus();
                Fetch();
                LoadUserId();
            } else {
                JOptionPane.showMessageDialog(this, "Account failed to deleted!!", "Alert", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            Logger.getLogger(Create.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_D1ActionPerformed

    private void C2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_C2ActionPerformed
        // TODO add your handling code here:
        TF1.setText("");
        TF2.setText("");
        TF3.setText("");
    }//GEN-LAST:event_C2ActionPerformed

    private void TF2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TF2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TF2ActionPerformed

    private void S1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_S1ActionPerformed

        try {
            String Combo = CB1.getSelectedItem().toString();

            pst = con.prepareStatement("SELECT * FROM name WHERE name=?");
            pst.setString(1, Combo);
            rs = pst.executeQuery();

            if (rs.next() == true) {
                TF1.setText(rs.getString(1));
                TF2.setText(rs.getString(2));
                TF3.setText(rs.getString(3));
                Fetch();
                LoadUserId();
            } else {
                JOptionPane.showMessageDialog(this, "No Account Found!!", "Alert", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            Logger.getLogger(Create.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_S1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        QueueList ql = new QueueList();
        ql.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Create.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Create.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Create.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Create.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Create().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BG;
    private javax.swing.JButton C1;
    private javax.swing.JButton C2;
    private javax.swing.JComboBox<String> CB1;
    private javax.swing.JButton D1;
    private javax.swing.JButton S1;
    private javax.swing.JTextField TF1;
    private javax.swing.JTextField TF2;
    private javax.swing.JPasswordField TF3;
    private javax.swing.JButton U1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
