/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finals;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Home extends javax.swing.JFrame {

    /**
     * Creates new form Home
     */
    public Home() {
        initComponents();
        img ();
        SIClogo();
        timeanddate();
    }
    
    public void SIClogo() {
        ImageIcon SIC = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\BG.jpg");
        Image img = SIC.getImage();
        Image imgScale = img.getScaledInstance(BG.getWidth(), BG.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledLogo = new ImageIcon(imgScale);
        BG.setIcon(scaledLogo);
    }
    public void img () {
    ImageIcon icon1 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Valorant.png");
    ImageIcon icon2 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Steam.png");
    ImageIcon icon3 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Roblox.png");
    ImageIcon icon4 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Garena.png");
    ImageIcon icon5 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\GTA.png");
    ImageIcon icon6 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\CS.png");
    ImageIcon icon7 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Growtopia.png");
    ImageIcon icon8 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Freefire.png");
    ImageIcon icon9 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Riot.png");
    ImageIcon icon10 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Firefox.png");
    ImageIcon icon11 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Google.png");
    ImageIcon icon12 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Excel.png");
    ImageIcon icon13 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Powerpoint.png");
    ImageIcon icon14 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Word.png");
    ImageIcon icon15 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Recycle.png");
    ImageIcon icon16 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Setting.png");
    ImageIcon icon17 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Google.png");
    ImageIcon icon18 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Microsoft.png");
    ImageIcon icon19 = new ImageIcon("C:\\Users\\albert\\Documents\\NetBeansProjects\\Finals\\src\\img\\Skype.png");
 
    
    Image games1 = icon1.getImage().getScaledInstance(i1.getWidth(), i1.getHeight(), Image.SCALE_SMOOTH);
    Image games2 = icon2.getImage().getScaledInstance(i2.getWidth(), i2.getHeight(), Image.SCALE_SMOOTH);
    Image games3 = icon3.getImage().getScaledInstance(i3.getWidth(), i3.getHeight(), Image.SCALE_SMOOTH);
    Image games4 = icon4.getImage().getScaledInstance(i4.getWidth(), i4.getHeight(), Image.SCALE_SMOOTH);
    Image games5 = icon5.getImage().getScaledInstance(i5.getWidth(), i5.getHeight(), Image.SCALE_SMOOTH);
    Image games6 = icon6.getImage().getScaledInstance(i6.getWidth(), i6.getHeight(), Image.SCALE_SMOOTH);
    Image games7 = icon7.getImage().getScaledInstance(i7.getWidth(), i7.getHeight(), Image.SCALE_SMOOTH);
    Image games8 = icon8.getImage().getScaledInstance(i8.getWidth(), i8.getHeight(), Image.SCALE_SMOOTH);
    Image games9 = icon9.getImage().getScaledInstance(i9.getWidth(), i9.getHeight(), Image.SCALE_SMOOTH);
    Image games10 = icon10.getImage().getScaledInstance(i10.getWidth(), i10.getHeight(), Image.SCALE_SMOOTH);
    Image games11 = icon11.getImage().getScaledInstance(i11.getWidth(), i11.getHeight(), Image.SCALE_SMOOTH);
    Image games12 = icon12.getImage().getScaledInstance(i12.getWidth(), i12.getHeight(), Image.SCALE_SMOOTH);
    Image games13 = icon13.getImage().getScaledInstance(i13.getWidth(), i13.getHeight(), Image.SCALE_SMOOTH);
    Image games14 = icon14.getImage().getScaledInstance(i14.getWidth(), i14.getHeight(), Image.SCALE_SMOOTH);
    Image games15 = icon15.getImage().getScaledInstance(i15.getWidth(), i15.getHeight(), Image.SCALE_SMOOTH);
    Image games16 = icon16.getImage().getScaledInstance(i16.getWidth(), i16.getHeight(), Image.SCALE_SMOOTH);
    Image games17 = icon17.getImage().getScaledInstance(i17.getWidth(), i17.getHeight(), Image.SCALE_SMOOTH);
    Image games18 = icon18.getImage().getScaledInstance(i18.getWidth(), i18.getHeight(), Image.SCALE_SMOOTH);
    Image games19 = icon19.getImage().getScaledInstance(i19.getWidth(), i19.getHeight(), Image.SCALE_SMOOTH);
 
    
    i1.setIcon(new ImageIcon(games1));
    i2.setIcon(new ImageIcon(games2));
    i3.setIcon(new ImageIcon(games3));
    i4.setIcon(new ImageIcon(games4));
    i5.setIcon(new ImageIcon(games5));
    i6.setIcon(new ImageIcon(games6));
    i7.setIcon(new ImageIcon(games7));
    i8.setIcon(new ImageIcon(games8));
    i9.setIcon(new ImageIcon(games9));
    i10.setIcon(new ImageIcon(games10));
    i11.setIcon(new ImageIcon(games11));
    i12.setIcon(new ImageIcon(games12));
    i13.setIcon(new ImageIcon(games13));
    i14.setIcon(new ImageIcon(games14));
    i15.setIcon(new ImageIcon(games15));
    i16.setIcon(new ImageIcon(games16));
    i17.setIcon(new ImageIcon(games17));
    i18.setIcon(new ImageIcon(games18));
    i19.setIcon(new ImageIcon(games19));

}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        t2 = new javax.swing.JLabel();
        i3 = new javax.swing.JLabel();
        i1 = new javax.swing.JLabel();
        t3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        i16 = new javax.swing.JLabel();
        i17 = new javax.swing.JLabel();
        i18 = new javax.swing.JLabel();
        i19 = new javax.swing.JLabel();
        T = new javax.swing.JLabel();
        D = new javax.swing.JLabel();
        i2 = new javax.swing.JLabel();
        t1 = new javax.swing.JLabel();
        i4 = new javax.swing.JLabel();
        t4 = new javax.swing.JLabel();
        i5 = new javax.swing.JLabel();
        t5 = new javax.swing.JLabel();
        i6 = new javax.swing.JLabel();
        t6 = new javax.swing.JLabel();
        i7 = new javax.swing.JLabel();
        t7 = new javax.swing.JLabel();
        i8 = new javax.swing.JLabel();
        i9 = new javax.swing.JLabel();
        i10 = new javax.swing.JLabel();
        i11 = new javax.swing.JLabel();
        i12 = new javax.swing.JLabel();
        i13 = new javax.swing.JLabel();
        i14 = new javax.swing.JLabel();
        t8 = new javax.swing.JLabel();
        t9 = new javax.swing.JLabel();
        t10 = new javax.swing.JLabel();
        t11 = new javax.swing.JLabel();
        t12 = new javax.swing.JLabel();
        t13 = new javax.swing.JLabel();
        t14 = new javax.swing.JLabel();
        i15 = new javax.swing.JLabel();
        t15 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        BG = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sword Internet Cafe");
        setResizable(false);

        jPanel1.setLayout(null);

        t2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t2.setForeground(new java.awt.Color(255, 255, 255));
        t2.setText("Steam");
        jPanel1.add(t2);
        t2.setBounds(20, 190, 40, 17);

        i3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Roblox.png"))); // NOI18N
        jPanel1.add(i3);
        i3.setBounds(10, 220, 60, 60);

        i1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i1);
        i1.setBounds(10, 20, 60, 60);

        t3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t3.setForeground(new java.awt.Color(255, 255, 255));
        t3.setText("Roblox");
        jPanel1.add(t3);
        t3.setBounds(20, 290, 50, 17);

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        i16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Setting.png"))); // NOI18N

        i17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Google.png"))); // NOI18N

        i18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Microsoft.png"))); // NOI18N

        i19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Skype.png"))); // NOI18N

        T.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        D.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(i16, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(107, 107, 107)
                .addComponent(i17, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(i18, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(i19, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 799, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(T, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(D, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(T)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(D))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(i19, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(i18, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(i16, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(i17, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(-10, 730, 1290, 60);

        i2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i2);
        i2.setBounds(10, 120, 60, 60);

        t1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t1.setForeground(new java.awt.Color(255, 255, 255));
        t1.setText("Valorant");
        jPanel1.add(t1);
        t1.setBounds(10, 90, 60, 17);

        i4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Garena.png"))); // NOI18N
        jPanel1.add(i4);
        i4.setBounds(10, 320, 60, 60);

        t4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t4.setForeground(new java.awt.Color(255, 255, 255));
        t4.setText("Garena");
        jPanel1.add(t4);
        t4.setBounds(20, 390, 50, 17);

        i5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/GTA.png"))); // NOI18N
        jPanel1.add(i5);
        i5.setBounds(10, 420, 60, 60);

        t5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t5.setForeground(new java.awt.Color(255, 255, 255));
        t5.setText("GTA 5");
        jPanel1.add(t5);
        t5.setBounds(20, 490, 40, 17);

        i6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i6);
        i6.setBounds(10, 520, 60, 60);

        t6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t6.setForeground(new java.awt.Color(255, 255, 255));
        t6.setText("Counter Strike");
        jPanel1.add(t6);
        t6.setBounds(10, 590, 100, 17);

        i7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i7);
        i7.setBounds(10, 620, 60, 60);

        t7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t7.setForeground(new java.awt.Color(255, 255, 255));
        t7.setText("Growtopia");
        jPanel1.add(t7);
        t7.setBounds(10, 690, 70, 17);

        i8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i8);
        i8.setBounds(120, 20, 60, 60);

        i9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i9);
        i9.setBounds(120, 120, 60, 60);

        i10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i10);
        i10.setBounds(120, 220, 60, 60);

        i11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i11);
        i11.setBounds(120, 320, 60, 60);

        i12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i12);
        i12.setBounds(120, 420, 60, 60);

        i13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i13);
        i13.setBounds(120, 520, 60, 60);

        i14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i14);
        i14.setBounds(120, 620, 60, 60);

        t8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t8.setForeground(new java.awt.Color(255, 255, 255));
        t8.setText("Firefire");
        jPanel1.add(t8);
        t8.setBounds(130, 90, 50, 17);

        t9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t9.setForeground(new java.awt.Color(255, 255, 255));
        t9.setText("Riot");
        jPanel1.add(t9);
        t9.setBounds(140, 190, 30, 17);

        t10.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t10.setForeground(new java.awt.Color(255, 255, 255));
        t10.setText("Firefox");
        jPanel1.add(t10);
        t10.setBounds(130, 290, 50, 17);

        t11.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t11.setForeground(new java.awt.Color(255, 255, 255));
        t11.setText("Google");
        jPanel1.add(t11);
        t11.setBounds(130, 390, 50, 17);

        t12.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t12.setForeground(new java.awt.Color(255, 255, 255));
        t12.setText("Excel");
        jPanel1.add(t12);
        t12.setBounds(130, 490, 40, 17);

        t13.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t13.setForeground(new java.awt.Color(255, 255, 255));
        t13.setText("Power Point");
        jPanel1.add(t13);
        t13.setBounds(120, 590, 100, 17);

        t14.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t14.setForeground(new java.awt.Color(255, 255, 255));
        t14.setText("Word");
        jPanel1.add(t14);
        t14.setBounds(130, 690, 40, 17);

        i15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Valorant.png"))); // NOI18N
        jPanel1.add(i15);
        i15.setBounds(220, 20, 60, 60);

        t15.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        t15.setForeground(new java.awt.Color(255, 255, 255));
        t15.setText("Recycle Bin");
        jPanel1.add(t15);
        t15.setBounds(220, 90, 80, 17);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 255));
        jLabel1.setText("Food Menu");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel1);
        jLabel1.setBounds(1160, 690, 90, 22);

        BG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BG.jpg"))); // NOI18N
        jPanel1.add(BG);
        BG.setBounds(0, 0, 1270, 730);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1271, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 785, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        Food food = new Food();
        food.show();
        dispose();
    }//GEN-LAST:event_jLabel1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }
    public void timeanddate() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    Date date = new Date();
                    SimpleDateFormat tformat = new SimpleDateFormat("hh:mm:ss aa");
                    SimpleDateFormat dformat = new SimpleDateFormat("EEEE, MM/dd/yyyy");
                    String time = tformat.format(date);
                    T.setText(time.split(" ")[0] + " " + time.split(" ")[1]);
                    D.setText(dformat.format(date));
                }
            }
        }).start();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BG;
    private javax.swing.JLabel D;
    private javax.swing.JLabel T;
    private javax.swing.JLabel i1;
    private javax.swing.JLabel i10;
    private javax.swing.JLabel i11;
    private javax.swing.JLabel i12;
    private javax.swing.JLabel i13;
    private javax.swing.JLabel i14;
    private javax.swing.JLabel i15;
    private javax.swing.JLabel i16;
    private javax.swing.JLabel i17;
    private javax.swing.JLabel i18;
    private javax.swing.JLabel i19;
    private javax.swing.JLabel i2;
    private javax.swing.JLabel i3;
    private javax.swing.JLabel i4;
    private javax.swing.JLabel i5;
    private javax.swing.JLabel i6;
    private javax.swing.JLabel i7;
    private javax.swing.JLabel i8;
    private javax.swing.JLabel i9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel t1;
    private javax.swing.JLabel t10;
    private javax.swing.JLabel t11;
    private javax.swing.JLabel t12;
    private javax.swing.JLabel t13;
    private javax.swing.JLabel t14;
    private javax.swing.JLabel t15;
    private javax.swing.JLabel t2;
    private javax.swing.JLabel t3;
    private javax.swing.JLabel t4;
    private javax.swing.JLabel t5;
    private javax.swing.JLabel t6;
    private javax.swing.JLabel t7;
    private javax.swing.JLabel t8;
    private javax.swing.JLabel t9;
    // End of variables declaration//GEN-END:variables
}
